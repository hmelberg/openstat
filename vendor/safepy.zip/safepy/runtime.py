# ============================================================================
# GENERATED COPY — DO NOT EDIT HERE.
# Source of truth: the safepy repo. This file is produced by sync_to_api.py.
# Edit the engine in the safepy repo and re-run that script; direct edits here
# are overwritten on the next sync.
# ============================================================================
"""Restricted execution of already-gated code.

Preconditions: ``code`` has passed :func:`safepy.ast_gate.validate`. The
gate guarantees the structural shape (simple assignments + final expression) and
that no banned node/verb/name is present, so this module only has to:

* build a namespace with ``__builtins__`` stripped to a tiny safe set,
* bind the library handles and the private data sources,
* exec the assignment prefix, eval the final expression, and
* sanitise any exception so it cannot carry a data value to the user.

This is defence-in-depth, not the primary guard. We never rely on
``__builtins__`` stripping alone to contain untrusted Python — the gate is what
makes the input trustworthy; this just narrows the blast radius further.
"""

from __future__ import annotations

import ast

from .errors import SafePythonError, SandboxError

# A minimal, audited builtin surface. Mirrors ast_gate._SAFE_BUILTINS plus the
# constants/exceptions ordinary expressions need. No import, eval, open, getattr.
import builtins as _b

_SAFE_BUILTINS = {
    name: getattr(_b, name)
    for name in ("len", "round", "abs", "int", "float", "str", "bool",
                 "True", "False", "None")
    if hasattr(_b, name)
}


def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
    """A controlled ``__import__`` resolving a whitelist of module names to safe
    facades and rejecting everything else. Reachable only via the import
    statement machinery (calling ``__import__`` directly is dunder-banned)."""
    root = name.split(".")[0]
    if root == "lifelines":
        from .lifelines_api import SafeLifelinesModule
        return SafeLifelinesModule()
    if root == "numpy":
        from .namespaces import SafeNp
        return SafeNp()
    if root == "pandas":
        from .namespaces import SafePd
        return SafePd()
    if root == "polars":
        from .polars_api import SafePl
        return SafePl()
    if root == "pyfixest":
        from .pyfixest_api import SafePyfixest
        return SafePyfixest()
    raise ImportError(f"module '{name}' is not available in safepy")


def execute(code: str, namespace: dict, *, allow_imports: bool = False, on_expr=None):
    """Run gated ``code`` and return ``(expr_values, ns)``.

    ``expr_values`` is the value of every top-level *bare expression* in the
    script, in order — each is a potential released result. Assignments/imports
    are executed for their side effects. ``ns`` is the post-execution namespace —
    the authoritative record of every bound name (used for the dataset catalog).
    ``__builtins__`` is overwritten here.

    ``on_expr`` (optional) is called with each bare-expression value immediately
    after it is evaluated — before the next statement runs — so callers can
    mediate and stream results while execution progresses.
    """
    ns = dict(namespace)
    builtins = dict(_SAFE_BUILTINS)
    if allow_imports:
        builtins["__import__"] = _safe_import
    ns["__builtins__"] = builtins

    tree = ast.parse(code, mode="exec")
    expr_values = []

    try:
        for stmt in tree.body:
            if isinstance(stmt, ast.Expr):
                value = eval(compile(ast.Expression(body=stmt.value), "<safepy>", "eval"), ns)
                expr_values.append(value)
                if on_expr is not None:
                    on_expr(value)
            else:
                exec(compile(ast.Module(body=[stmt], type_ignores=[]), "<safepy>", "exec"), ns)
    except SafePythonError:
        # Our own errors (DisclosureError/ValidationError raised by safe verbs)
        # carry no data values and are meant to be shown to the user verbatim.
        raise
    except BaseException as exc:  # noqa: BLE001 - deliberately broad; message is dropped
        # Do NOT include str(exc): it may contain a data value (KeyError on a
        # name, an assertion message, a formatted row). Keep only the type for
        # the audit; show the user nothing data-bearing.
        raise SandboxError(
            f"your code raised {type(exc).__name__} during execution"
        ) from None
    return expr_values, ns
